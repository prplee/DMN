package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.SaleDTO;


public class SaleDAO {

	public List<SaleDTO> saleList(SqlSession session,String userid) {
		List<SaleDTO> list =  session.selectList("SaleMapper.saleList",userid);
		return list;
	}

}
