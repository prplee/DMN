package com.dto;

public class SaleDTO {
	private String userid;
	private String saleno;
	private String product;
	private String salecomplete;
	
	public SaleDTO(String userid,String saleno, String product, String salecomplete) {
		super();
		this.userid = userid;
		this.saleno = saleno;
		this.product = product;
		this.salecomplete = salecomplete;
	}

	public SaleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getSaleno() {
		return saleno;
	}

	public void setSaleno(String saleno) {
		this.saleno = saleno;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getSalecomplete() {
		return salecomplete;
	}

	public void setSalecomplete(String salecomplete) {
		this.salecomplete = salecomplete;
	}

	@Override
	public String toString() {
		return "SaleDTO [userid=" + userid + ", saleno=" + saleno + ", product=" + product + ", salecomplete="
				+ salecomplete + "]";
	}

	

	
	
}
