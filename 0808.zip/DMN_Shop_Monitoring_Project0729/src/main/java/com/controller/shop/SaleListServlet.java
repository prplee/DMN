package com.controller.shop;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.SaleDTO;
import com.dto.SawonDTO;
import com.service.SaleService;
import com.service.SawonService;

/**
 * Servlet implementation class CartListServlet
 */
@WebServlet("/CartListServlet")
public class SaleListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaleListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
	      SawonDTO dto = (SawonDTO)session.getAttribute("login");
	      String nextPage = null;
	      if(dto!=null) {
	      String userid =dto.getUserid();
	      SaleService service = new SaleService();
	      List<SaleDTO> list= service.saleList(userid);
	    
	      request.setAttribute("saletList", list);
	      }else {
			nextPage = "LoginUIServlet";
			session.setAttribute("mesg", "로그인이 필요한 작업입니다.");
		}
	      RequestDispatcher dis = request.getRequestDispatcher(nextPage);
			dis.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
