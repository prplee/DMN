package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.SaleDAO;
import com.dto.SaleDTO;

public class SaleService {

	public List<SaleDTO> saleList() {
		
		SqlSession session = MySqlSessionFactory.getSession();
		List<SaleDTO> list = null;
		try {
			  SaleDAO dao = new SaleDAO();
		      list = dao.saleList(session);
		      }finally {
				session.close();
		      }
		      return list;
	
	}

}
