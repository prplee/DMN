package com.dto;

public class SaleDTO {
	
	private int saleno;
	private String product;
	private String salecomplete;
	
	public SaleDTO(String userid,int saleno, String product, String salecomplete) {
		super();
		this.saleno = saleno;
		this.product = product;
		this.salecomplete = salecomplete;
	}

	public SaleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public int getSaleno() {
		return saleno;
	}

	public void setSaleno(int saleno) {
		this.saleno = saleno;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getSalecomplete() {
		return salecomplete;
	}

	public void setSalecomplete(String salecomplete) {
		this.salecomplete = salecomplete;
	}

	@Override
	public String toString() {
		return "SaleDTO [saleno=" + saleno + ", product=" + product + ", salecomplete=" + salecomplete + "]";
	}



	

	
	
}
